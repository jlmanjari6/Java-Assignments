/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappings;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class CourseDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner sc = new Scanner(new File("input.txt"));
        CourseMapping enrollments = new CourseMapping();
        Person student = null;
        while (sc.hasNextLine()) {
            String next = sc.nextLine();
            if (next.equals("Student")) {
                String name = sc.nextLine();
                student = new Person(name);
            } else {
                String[] values = next.split("-");
                Person faculty = new Person(values[1]);
                Course course = new Course(values[0], values[2], faculty);
                enrollments.addEnrollments(student, course);
            }
        }

        System.out.println("Number of students enrolled in \"44460\" in \"Fall 2016\" with \"Dr. Charles Badami\"");
        System.out.println(enrollments.findNumberOfStudents("Charles Badami", "Fall 2016", "44460"));

        System.out.println("\nCourses taught by \"Dr. Aziz Fellah\"");
        System.out.println(enrollments.findCoursesTaught("Aziz Fellah"));

        System.out.println("\nStudents enrolled for \"44692\" in \"Fall 2017\"");
        System.out.println(enrollments.findStudentsEnrolled("44692", "Fall 2017"));

        System.out.println("\nSize of hash map: " + enrollments.size());

        //Create a Scanner object to read Student and course details from "input.txt" file.
        //Create an object of CourseMapping and name it as "enrollments".
        //Declare an object for Person, name it as "student" and initialize it to null
        //while input.txt has more data(While loop starts here) {
        //Read the first line,If the passed type is "Student" then, read in the "name".
        //Create an object for Person with above read value and assign it to "student" variable.
        //Else, read the next line, It will be in the following order: courseNo, faculty name and semester 	//separated by comma separator.
        // With above read values, create an object Course and name it as "course".
        //Invoke addEnrollments() on "enrollments" object and add the "student","course".
        // } (while loop ends here)
        // Print number of students enrolled in "44460" in "Fall 2016" with "Charles Badami"
        // Print courses taught by "Aziz Fellah"
        // Print students enrolled for "44692" in "Fall 2017"
        // Print size of the hash map.
    }

}
