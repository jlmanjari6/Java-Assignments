/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappings;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class CourseMapping implements Iterable {

    private HashMap<Person, LinkedList<Course>> studentEnrollment;

    public CourseMapping() {
        studentEnrollment = new HashMap<>();
    }

    /**
     * This method adds a new entry to the studentEnrollment. The first
     * parameter is the key for entry. Second parameter should be appended to
     * the linked list value of the person in hashMap. Hint: If courses
     * associated to the person is null then add the person with new
     * LinkedList<> to the hashMap.
     *
     * @param person
     * @param course
     */
    public void addEnrollments(Person person, Course course) {
        if (!(studentEnrollment.containsKey(person))) {
            LinkedList<Course> list = new LinkedList<>();
            list.add(course);
            studentEnrollment.put(person, list);
        } else {
            studentEnrollment.get(person).add(course);
        }
    }

    /**
     * This method returns the number of students who have taken the course in
     * given semester with the faculty
     *
     * @param facultyName
     * @param semester
     * @param courseNo
     * @return
     */
    public int findNumberOfStudents(String facultyName, String semester, String courseNo) {
        int count = 0;
        for (LinkedList<Course> courseList : studentEnrollment.values()) {
            for (int i = 0; i < courseList.size(); i++) {
                if (courseList.get(i).getCourseNo().equals(courseNo)
                        && courseList.get(i).getFaculty().getName().equals(facultyName)
                        && courseList.get(i).getSemester().equals(semester)) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * This method returns set of all the courses taught by given faculty.
     *
     * @param facultyName
     * @return
     */
    public Set<String> findCoursesTaught(String facultyName) {
        Set<String> courses = new HashSet<>();
        for (LinkedList<Course> courseList : studentEnrollment.values()) {
            for (int i = 0; i < courseList.size(); i++) {
                if (courseList.get(i).getFaculty().getName().equals(facultyName)) {
                    courses.add(courseList.get(i).getCourseNo());
                }
            }
        }
        return courses;
    }

    /**
     * This method returns list of students enrolled for a course in given
     * semester
     *
     * @param course
     * @param semester
     * @return
     */
    public List<Person> findStudentsEnrolled(String course, String semester) {
        List<Person> studentsList = new LinkedList<>();
        Iterator it = this.iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            LinkedList<Course> coursesList = (LinkedList<Course>) pair.getValue();
            for (int i = 0; i < coursesList.size(); i++) {
                if (coursesList.get(i).getCourseNo().equals(course) && coursesList.get(i).getSemester().equals(semester)) {
                    studentsList.add((Person) pair.getKey());
                }
            }
        }
        return studentsList;
    }

    /**
     * This is the getter method for instance variable.
     *
     * @return
     */
    public HashMap<Person, LinkedList<Course>> getStudentEnrollment() {
        return studentEnrollment;
    }

    /**
     * This method returns an iterator over studentEnrollment.
     *
     * @return
     */
    @Override
    public Iterator iterator() {
        return studentEnrollment.entrySet().iterator();
    }

    /**
     * This methods returns size of the hashMap
     *
     * @return
     */
    public int size() {
        return studentEnrollment.size();
    }

}
