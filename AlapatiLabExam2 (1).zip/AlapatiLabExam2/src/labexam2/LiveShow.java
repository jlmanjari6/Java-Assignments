/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class LiveShow extends TicketBooking {

    public LiveShow(String name, int numOfTickets, double costPerTicket) {
        super(name, numOfTickets, costPerTicket);
    }

    @Override
    double computeTotalCost() {
        return super.getCostPerTicket() * super.getNumOfTickets();
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "Total Amount for Live Show       " + this.computeTotalCost();
    }

}
