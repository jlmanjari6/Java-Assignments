/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class Movie extends TicketBooking {

    private double tax;

    public Movie(String name, int numOfTickets, double costPerTicket, double tax) {
        super(name, numOfTickets, costPerTicket);
        this.tax = tax;
    }

    public double getTax() {
        return tax;
    }

    @Override
    double computeTotalCost() {
        double totalCost = super.getCostPerTicket() * super.getNumOfTickets();
        return totalCost * tax + totalCost;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "Total Amount for Movie+Tax       " + this.computeTotalCost();
    }

}
