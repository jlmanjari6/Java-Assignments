/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2;

import java.util.ArrayList;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class MultiplexBookingDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<TicketBooking> tikts = new ArrayList<>();
        int totalNoOfTickets = 0, noOfBookingsOverHundred = 0;

        tikts.add(new Movie("James", 10, 25, 0.20));
        tikts.add(new Movie("Milan", 0, 25, 0.20));
        tikts.add(new Movie("Milan", 4, 25, 0.20));

        tikts.add(new LiveShow("Roma", 0, 12));
        tikts.add(new LiveShow("Brown", 5, 12));

        for (TicketBooking t : tikts) {
            System.out.println(t.toString());
            System.out.println("-----------------------------");
        }

        for (TicketBooking t : tikts) {
            totalNoOfTickets += t.getNumOfTickets();
            if (t.computeTotalCost() > 100) {
                noOfBookingsOverHundred++;
            }
        }

        System.out.println("No. of Tickets Booked " + totalNoOfTickets);
        System.out.println("No. of Bookings over 100$ are " + noOfBookingsOverHundred);

    }

}
