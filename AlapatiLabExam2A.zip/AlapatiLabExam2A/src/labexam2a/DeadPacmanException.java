/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam2a;

/**
 *
 * @author S530719
 */
public class DeadPacmanException extends Exception {

    public DeadPacmanException() {
    }
    
}
