/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam1;

import java.util.Scanner;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class EnvelopeTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Testing the Envelope class.");
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter a tracking id for envelope 1 ");
        String trackingIdEnv1 = scan.nextLine();
        Envelope env1 = new Envelope(trackingIdEnv1);
        System.out.println(env1);
        System.out.println( env1.getWeight() + " " + env1.getTrackingId());
        System.out.println("Please enter a weight and a tracking Id for envelope 2 ");
        double weightEnv2 = scan.nextDouble();
        String trackindIdEnv2 = scan.next();
        Envelope env2 = new Envelope(weightEnv2, trackindIdEnv2);
        System.out.println(env2);
        env2.addWeight(21);
        env1.addWeight(-1000);
        System.out.println("");
        System.out.println(env1); //Expected output was given wrong
        System.out.println(env2); //Expected output was given wrong
        System.out.println("Postage env1:" + env1.computePostage()); //Expected output was given wrong
        System.out.println("Postage env2:" + env2.computePostage()); //Expected output was given wrong
        System.out.println("Priority env1:" + env1.isPriority());
        System.out.println("Priority env2:" + env2.isPriority());
        System.out.println("Testing on Envelope complete");
    }
    
}
