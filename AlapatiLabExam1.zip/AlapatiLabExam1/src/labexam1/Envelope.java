/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labexam1;

/**
 *
 * @author Lakshmi Manjari Alapati
 */
public class Envelope {
    private double weight;
    private String trackingId;
    
    public Envelope(String trackingId){
        this.weight = 100.0;
        this.trackingId = trackingId;
    }
    
    public Envelope(double weight, String trackingId){
        this.weight = weight;
        this.trackingId = trackingId;
    }
    
    public double getWeight(){
        return weight;
    }
    
    public String getTrackingId() {
        return trackingId;
    }

    @Override
    public String toString() {
        return "Envelope{" + "weight=" + weight + ", trackingId=" + trackingId + '}';
    }
    
    public void addWeight(double amount){
        if(amount > 0){
            weight += amount;
        }
    }
    
    public double computePostage() {
        return 10 + Math.sqrt(weight);
    }
    
    public boolean isPriority(){
        return (trackingId.substring(0, 3).equals("PRI"));
    }
}
